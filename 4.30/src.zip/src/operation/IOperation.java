package operation;

import book.BookList;

/**
 * Created with IntelliJ IDEA.
 * Description:
 * User: GAOBO
 * Date: 2020-04-30
 * Time: 19:45
 */
public interface IOperation {
    void work(BookList bookList);
}

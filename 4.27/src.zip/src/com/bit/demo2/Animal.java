package com.bit.demo2;

/**
 * Created with IntelliJ IDEA.
 * Description:
 * User: GAOBO
 * Date: 2020-04-27
 * Time: 19:19
 */
public class Animal {
    protected String name;
}

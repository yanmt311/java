package com.bit.demo2;
/**
 * Created with IntelliJ IDEA.
 * Description:
 * User: GAOBO
 * Date: 2020-04-27
 * Time: 19:20
 */
public class TestDemo1 {
    public static void main(String[] args) {
        Animal animal = new Animal();
        System.out.println(animal.name);
    }
}
